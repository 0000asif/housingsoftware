@extends('admin.masterAdmin')
@section('content')
    <!-- BEGIN: Page content-->
    <div>
        <div class="card">
            <div class="card-header">
                <h5 class="box-title">Increase/Decrease</h5>
            </div>
            <div class="card-body">
                <br>
                @include('components/alert')
                <form action="{{ route('RentIncreaseDecrease.Store') }}" enctype="multipart/form-data" method="post">
                    @csrf

                    <!-- Main Renter Information -->
                    <div class="form-section">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Select Renter<span style="color: red;">*</span></label>
                                <select class="form-control select2_demo" id="renter_id" name="renter_id" required>
                                    <option value="">Select an option</option>
                                    @foreach ($renters as $item)
                                        <option value="{{ $item->id }}">
                                            {{ $item->name }}-
                                            {{ $item->phone }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="rentDate" class="form-label">Date<span style="color: red;">*</span></label>
                                <input type="text" placeholder="Date" required name="rent_date" id="rentDate"
                                    class="form-control datetimepicker_5">
                            </div>
                        </div>
                    </div>

                    <!-- Rent Details -->
                    <div class="form-section">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="monthlyRent" class="form-label">Monthly Rent<span
                                        style="color: red;">*</span></label>
                                <input type="number" name="monthly_rent" required id="monthlyRent" class="form-control"
                                    placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="electricityBill" class="form-label">Electricity Bill</label>
                                <input type="number" name="electracity_bill" id="electricityBill" class="form-control"
                                    placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="waterBill" class="form-label">Water Bill</label>
                                <input type="number" id="waterBill" name="water_bill" class="form-control" placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="gasBill" class="form-label">Gas Bill</label>
                                <input type="number" id="gasBill" name="gas_bill" class="form-control" placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Gatman bill</label>
                                <input type="number" id="" name="gatmanbill" class="form-control" placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Lift bill</label>
                                <input type="number" id="" name="lift_bill" class="form-control" placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="form-label">Car/Bike REG NO.</label>
                                        <input type="number" id="" name="car_reg_no" class="form-control"
                                            placeholder="0">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Car/Bike Qty</label>
                                        <input type="number" id="" name="quantity" class="form-control"
                                            placeholder="0">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Garage Bill</label>
                                <input type="number" id="" name="garage_bill" class="form-control"
                                    placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Service Charge</label>
                                <input type="number" id="" name="service_charge" class="form-control"
                                    placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Advance</label>
                                <input type="number" id="" name="advance" class="form-control"
                                    placeholder="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Family Member</label>
                                <input type="number" id="" name="member" class="form-control"
                                    placeholder="0">
                            </div>
                        </div>

                    </div>


                    <div class="form-group mr-2">
                        <button class="btn btn-primary" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
    <!-- END: Page content-->
@endsection
